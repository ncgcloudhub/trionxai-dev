=== king ===
Author: RedKings
Author URI: http://themeforest.net/user/RedKings
Requires at least: WordPress 4.1
Tested up to: WordPress 5.8
Theme URI: http://kingthemes.net
Version: 9.0.1
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: light, one-column, two-columns, three-columns, left-sidebar, right-sidebar, flexible-header, fluid-layout, responsive-layout, blavatar, custom-colors, custom-header, custom-menu, editor-style, featured-images, featured-image-header, post-formats, sticky-post, theme-options, translation-ready, photoblogging


== Description ==
King is most powerful and flexible viral and buzz style WordPress theme.

For more information about King please go to kingthemes.org

== Installation ==

Please see installation guide in Documentation.

